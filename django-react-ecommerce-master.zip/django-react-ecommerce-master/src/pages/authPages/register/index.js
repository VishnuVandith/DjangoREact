export { default } from "./Register";
