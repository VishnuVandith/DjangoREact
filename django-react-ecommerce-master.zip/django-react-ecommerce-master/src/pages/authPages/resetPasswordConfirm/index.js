export { default } from "./ResetPasswordConfirm";
