export { default } from "./ProductsDetail";
