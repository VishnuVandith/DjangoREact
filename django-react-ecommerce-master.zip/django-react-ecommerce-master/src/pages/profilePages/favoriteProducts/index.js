export { default } from "./FavoriteProducts";
