export { default } from "./OrdersDetail";
